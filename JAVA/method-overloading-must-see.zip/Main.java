
public class Main
{
    public static void sum(int a,int b)     // static is must o.w prog. wont work as we r calling them without object
	{
	    System.out.println(a+b);
	}
	
	public static void sum(int a,int b,int c)     // static is must o.w prog. wont work as we r calling them without object
	{
	    System.out.println(a+b+c);
	}
		
	public static void sum(float a,float b)  // static is must o.w prog. wont work as we r calling them without object
	{
	    System.out.println(a+b);
	}
	
	public static void sum(String a,String b)  // static is must o.w prog. wont work as we r calling them without object
	{
	    System.out.println(a+b);
	}
		
	public static void main(String[] args) 
    {
		sum(3.4f,2.3f);       // f is must o.w program wont work
		sum(3,4);
		sum(1,2,3);
		sum("Sourabh"," Gadhe");
	}
}


