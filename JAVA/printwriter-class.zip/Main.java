
// print writer class
  

import java.io.PrintWriter; 

public class Main { 
    
    public static void main(String[] args)
    {  
             //Data to write on Console using PrintWriter  
      PrintWriter writer = new PrintWriter(System.out);  
      
      writer.printf(" Sourabh Gadhe %s ","boss");    
      writer.print("\n HI ");
      writer.println("\n GADHE " );
      writer.write(" si");
      
      writer.flush();  
      writer.close(); 
    }
}

