class Parent
{
    void run()
    {
        System.out.println("Parent running");
    }
    
    void show()
    {
        System.out.println("Showing");
    }
}

class Child extends Parent
{
    void run()
    {
        System.out.println("Child running");
    }
}

public class Main
{
    public static void main (String[] args) {
        Parent p = new Child();               // upcasting // p can call all methods of Parent but only overridden 
                                            // method is called from child class
        p.run();
        p.show();
    }
}