abstract class Bike 
{
    abstract void run();
    
    void play()
    {
        System.out.println("playing");
    }
   
}

class Honda extends Bike
{
    void run()
    {
        System.out.println("Bike running");
    }
}

public class Main
{
    public static void main (String[] args) {
        Bike b = new Honda();
        
        // Bike b = new Bike();  // error -> Bike cannot be instantiated as it is abstract
        
        b.run();   // overridden method is called
        b.play();  
    }
}