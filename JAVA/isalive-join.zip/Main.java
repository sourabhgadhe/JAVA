// 1. isAlive() method

// class Mythread1 extends Thread
// {
//     public void run()
//     {
       
//     }
// }

// class Mythread2 extends Thread
// {
//     public void run()
//     {
        
//     }
// }

// public class Main
// {
//     public static void main (String[] args) {
//         Mythread1 mt1 = new Mythread1();
//         Mythread2 mt2 = new Mythread2();
   
//         mt1.start();
//         System.out.println(mt1.isAlive());  // true
//         System.out.println(mt2.isAlive());  // false
//         mt2.start();
//         System.out.println(mt2.isAlive());  // true
//     }
// }









// 2. join() method


class Mythread1 extends Thread
{
    public void run()
    {
        for(int i=0;i<3;i++)
            System.out.println("Sourabh");
    }
}

class Mythread2 extends Thread
{
    public void run()
    {
        for(int i=0;i<3;i++)
            System.out.println("Gadhe");
    }
}

public class Main
{
    public static void main (String[] args) {
        Mythread1 mt1 = new Mythread1();
        Mythread2 mt2 = new Mythread2();
   
        mt1.start();
        try 
        {
            mt1.join();
        }
        
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        mt2.start();
    }
}







