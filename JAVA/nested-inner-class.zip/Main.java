class Outer 
{
    int a = 4;
    
    class Inner 
    {
        int b=1;
    }
}

public class Main 
{
    public static void main (String[] args) 
    {
        Outer obj1 = new Outer();
        
        Outer.Inner obj2 = obj1.new Inner();  // M.IMP  remember 
        
        System.out.println(obj1.a); // 4
        System.out.println(obj2.b);  // 1 
        
        System.out.println(obj1.b); // error
        System.out.println(obj2.a); // error
    }
}