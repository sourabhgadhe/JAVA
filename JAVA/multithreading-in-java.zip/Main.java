// 1. using Runnable interface

// class Mythread1 implements Runnable
// {
//     public void run()
//     {
//         for(int i=0;i<3;i++)
//             System.out.println("Sourabh "+i);
//     }
// }

// class Mythread2 implements Runnable
// {
//     public void run()
//     {
//         for(int i=0;i<3;i++)
//             System.out.println("Gadhe "+i);
//     }
// }

// public class Main
// {
//     public static void main (String[] args) {
//         Mythread1 mt1 = new Mythread1();
//         Thread t1 = new Thread(mt1);
        
//         Mythread2 mt2 = new Mythread2();
//         Thread t2 = new Thread(mt2);
        
//         t1.start();
//         t2.start();
//     }
// }







// 2. by extending Thread class

class Mythread1 extends Thread
{
    public void run()
    {
        for(int i=0;i<3;i++)
            System.out.println("Sourabh "+i);
    }
}

class Mythread2 extends Thread
{
    public void run()
    {
        for(int i=0;i<3;i++)
            System.out.println("Gadhe "+i);
    }
}

public class Main
{
    public static void main (String[] args) {
        Mythread1 mt1 = new Mythread1();
        Mythread2 mt2 = new Mythread2();
   
        mt1.start();
        mt2.start();
    }
}







