
//Default Constructor

// class Geek 
// {
//     Geek() { System.out.println("Default Constructor called !!"); }
// }
  
// public class Main {
//     public static void main(String[] args)
//     {
//         Geek g1 = new Geek();
//     }
// }



// Parameterized Constructor
// class Geek 
// {
//     Geek(int roll,String s)        // while writing String datatype variable, S in String must be capital 
//     {
//         System.out.println(roll);
//         System.out.println(s);
//     }
// }

// public class Main
// {
//     public static void main (String[] args) {
//         Geek g = new Geek(19,"Sourabh");
//     }
// }



// Copy Constructor
class Geek
{
    int roll;
    String name;       // separate copy of data members is created for each created object 
    
    Geek(int roll,String name)
    {
        this.name=name;
        this.roll=roll;
    }
    
    Geek(Geek g)
    {
        System.out.println("\nCopy Constructor called !!\n");
      
        this.roll=g.roll;
        this.name=g.name;
    }
}

public class Main
{
    public static void main (String[] args) {
        
        Geek g1 = new Geek(19,"Sourabh");
        System.out.println(g1.name);
        System.out.println(g1.roll);
        
        Geek g2 = new Geek(g1);
        System.out.println(g2.name);
        System.out.println(g2.roll);
    }
}





















