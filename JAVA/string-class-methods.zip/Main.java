// String class Methods

import java.util.*;

public class Main
{
    public static void main (String[] args) {
        String s1 = "Sourabh";
        String s2 = "    GADHE    ";
        String s3 = "Sourabh";
        String s4 = "";
        
        System.out.println(s1.length()); // 7
        System.out.println(s1.charAt(0)); // S
        System.out.println(s1.startsWith("Sou")); // true
        System.out.println(s1.endsWith("bh")); // true
        System.out.println(s1.indexOf("ou")); // 1
        System.out.println(s1.toUpperCase()); // SOURABH
        
        System.out.println(s2.trim()); //GADHE  --> remove whitespaces before & after
        System.out.println(s1.compareTo(s3)); // 0 returns ascii difference
        System.out.println(s3.toLowerCase()); // sourabh
        System.out.println(s3.replace("abh","***")); // Sour***
        System.out.println(s4.isEmpty()); // true
        
    }
}