// 1. final variable

// public class Main
// {  
//  final int speedlimit=90;//final variable  
//  void run()
//  {  
//   speedlimit=400;  
//  }  
 
//  public static void main(String args[]){  
//  Main obj=new  Main();  
//  obj.run();               // compile time error
//  } 
 
// }


// 2. final method

// class Bike
// {  
//   final void run()                  // final method cannot br overriden
//   {System.out.println("running");}  
// }  
     
// class Honda extends Bike
// {  
//   void run()
//   {System.out.println("running safely with 100kmph");}  
// }

// public class Main
// {
//   public static void main(String args[])
//   {  
//         Honda honda= new Honda();  
//         honda.run();                  // gives compile time error
//   } 
// }


// 3. final class
final class Parent            // final class cannot br inheried
{
    
}

class Child extends Parent       
{
    
}

class Main 
{
    public static void main (String[] args)
    {
        Child c = new Child();
    }
}