import java.util.*;
import java.util.Scanner;

public class Main
{
   public static void main (String[] args) {
       Scanner sc = new Scanner(System.in);
       int[][] arr1 = new int[10][10];
       int[][] arr2 = new int[10][10];
       int[][] res = new int[10][10];
       System.out.println("\nEnter no. of rows: ");
       int r = sc.nextInt();
       System.out.println("\nEnter no. of cols: ");
       int c = sc.nextInt();
       System.out.println("\nEnter the elements of 1st matrix: ");
       for(int i=0;i<r;i++)
       {
           for(int j=0;j<c;j++)
           {
               arr1[i][j]=sc.nextInt();
           }
       }
       
       System.out.println("\nEnter the elements of 2nd matrix: ");
       for(int i=0;i<r;i++)
       {
           for(int j=0;j<c;j++)
           {
               arr2[i][j]=sc.nextInt();
           }
       }
       
       for(int i=0;i<r;i++)
       {
           for(int j=0;j<c;j++)
           {
               res[i][j]=arr1[i][j]+arr2[i][j];
           }
       }
       
    //   for(int i=0;i<r;i++)
    //   {
    //       for(int j=0;j<c;j++)   // making diagonal elements 0
    //       {
    //           if(i==j)
    //           {
    //               res[i][j]=0;
    //           }
    //       }
    //   }
       
       System.out.println("\nThe resultant matrix is: ");
       for(int i=0;i<r;i++)
       {
           for(int j=0;j<c;j++)
           {
               System.out.print(res[i][j]+" ");
           }
           System.out.println();
       }
       
       
       
   } 
}
