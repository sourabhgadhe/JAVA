// // Single inheritance 

// class Animal
// {  
//     void eat(){System.out.println("eating...");}  
// }  

// class Dog extends Animal
// {  
//     void bark(){System.out.println("barking...");}  
// }

// public class Main                // must be Main class for prog to work
// {  
//     public static void main(String args[])
//     {  
//         Dog d=new Dog();  
//         d.bark();  
//         d.eat();  
//     }
// } 





// // Multilevel inheritance

// class Animal
// {  
//     void eat(){System.out.println("eating...");}  
// }  
// class Dog extends Animal
// {  
//     void bark(){System.out.println("barking...");}  
// }  
// class BabyDog extends Dog                               
// {  
//     void weep(){System.out.println("weeping...");}  
// }  
// public class Main
// {  
//     public static void main(String args[])
//     {  
//         BabyDog d=new BabyDog();  
//         d.weep();  
//         d.bark();  
//         d.eat();  
//     }
// }  





// Hierarchical Inheritance

// class Animal
// {  
//     void eat(){System.out.println("eating...");}  
// }  
// class Dog extends Animal
// {  
//     void bark(){System.out.println("barking...");}  
// }  
// class Cat extends Animal                                   
// {  
//     void meow(){System.out.println("meowing...");}  
// }  
// public class Main                // the class must be public and named as "Main" in which main method is defined
// {  
//     public static void main(String args[]){  
//     Cat c=new Cat();  
//     c.meow();  
//     c.eat();  
//     //c.bark();//C.T.Error  
//     }
// }  



// Hybrid & Multiple Inheritance is achieved using interfaces


