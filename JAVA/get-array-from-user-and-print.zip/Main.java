import java.util.*;
public class Main
{
                                                // int a[] = {1,2,3,4,5};   Valid declaration
                                                // int a[4] = {1,2,3,4};    Invalid declaration
    public static void main(String[] args)
    {
        
       Scanner sc = new Scanner(System.in);
       int array[] = new int[10];              // declaring array     int arr[10];  is invalid
                                               //                     int arr[];    valid
                                               //                     int arr[] = new int[];    invalid as size is not specified
       System.out.print("How many nos in array ? ");
       int n = sc.nextInt();
       for(int i=0; i<n; i++)
       {
           System.out.println("Enter a number: ");
           array[i] = sc.nextInt();
       }
       
       for(int i=0; i<n; i++)
       {
           System.out.println("Array elems are : " + array[i]);
       }
        
  
    }

    
}


