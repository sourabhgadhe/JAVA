
public class Main
{
    static int sum(int a,int b)  // if we write static, no need to create object of class for calling the function
    {
        return a+b;
    }
	public static void main(String[] args) {
		int x=4;
		int y=5;
		int result = sum(x,y);  // sum is static function, so no need to call it with a object 
		System.out.println(result);
	}
}
 // Similary variables can also be static


// public class Main                 
// {
//     int sum(int a,int b)        // if we dont write static we've to create a object of class and then call the function  
//     {                           // using that object
//       return a+b;
//     }
// 	public static void main(String[] args) {
// 		int x=4;
// 		int y=5;
// 		Main m = new Main();
// 		int result = m.sum(x,y);  // sum is not static function, so call it with a object
// 		System.out.println(result);
// 	}
// }
