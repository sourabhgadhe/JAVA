
public class Main
{
    static void sum(int... numbers)
    {
        int sum=0;
        for(int i=0;i<numbers.length;i++)
        {
            sum+=numbers[i];
        }
        
        System.out.println(sum);
    }
    
	public static void main(String[] args) {
		sum(1,2);
		sum(3,5,6);
		sum(2,-1,4);
	}
}

