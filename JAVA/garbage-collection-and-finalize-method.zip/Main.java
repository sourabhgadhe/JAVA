
public class Main
{
    protected void finalize() 
    {
        System.out.println("object is garbage collected");
    }
    
	public static void main(String[] args) 
	{
	    Main m1 = new Main();
	    Main m2 = new Main();
	    Main m3 = new Main();
	    
	    m1=null;        // must for executing finalize() method
	    m2=null;       // must for executing finalize() method 
	    
	    System.gc();  //as m3 has not been yet made null (i.e still being used) .gc() will call finalize() only for m1 & m2 objects
	                   // .gc() calls finalize() only for unused objects (in this case m1 & m2 are unused i.e null)
	}
}




// class Sourabh
// {
//     protected void finalize()
//     {
//         System.out.println("Sourabh ha ha");
//     }
// }

// class Gadhe
// {
//     protected void finalize()
//     {
//         System.out.println("Gadhe ha ha");
//     }
// }

// public class Main 
// {
//     public static void main (String[] args) {
//         Gadhe g1 = new Gadhe();             
//         Sourabh s1 = new Sourabh();           // last object 
        
//         s1=null;
//         g1 = null;
   
//         System.gc();  // gc calls last created object's finalize() first
//     }
// }


