// Interface example

//example 1
// interface printable{  
// void print();  
// }  
// class Main implements printable{  
// public void print(){System.out.println("Hello");}  
  
// public static void main(String args[]){  
// Main obj = new Main();  
// obj.print();  
//  }  
// }

//example 2
// interface Drawable{  
// void draw();  
// }  
// //Implementation: by second user  
// class Rectangle implements Drawable{  
// public void draw(){System.out.println("drawing rectangle");}  
// }  
// class Circle implements Drawable{  
// public void draw(){System.out.println("drawing circle");}  
// }  
// //Using interface: by third user  
// class Main{  
// public static void main(String args[]){  
// Drawable d = new Circle(); // upcasting
// d.draw();  
// }} 




// Multiple Inheritance using Interface

// 1. class implements multiple interfaces

// interface Printable{  
// void print();  
// }  
// interface Showable{  
// void print();  
// }  
  
// class Main implements Printable, Showable{  
// public void print(){System.out.println("Hello");}  
// public static void main(String args[]){  
// Main obj = new Main();  
// obj.print();  
//  }  
// }


// 2. Interface implements multiple interfaces

// interface Printable
// {  
//     void print();  
// }  
// interface Showable 
// {  
//     void show();  
// }  

// interface Result extends Printable,Showable
// {
//     void res();
// }

// class Main implements Result
// {  
    
//     public void print(){System.out.println("Hello");}
//     public void show(){System.out.println("Welcome");} 
//     public void res(){System.out.println("Result");}
  
//     public static void main(String args[])
//     {  
//         Main obj = new Main();  
        
//         obj.print();  
//         obj.show(); 
//         obj.res();
        
//     }  
// }  





// Nested Interface


//1. Interface nested in another interface

// interface Showable
// {
//     void show();   
    
//     interface Message   // interface is always abstract as it contains abstract methods & hence cannot be instantiated
//     {
//         void msg();  
//     }  
// }  
// class Main implements Showable.Message
// {
//     public void msg()
//     {
//         System.out.println("Hello nested interface");
//     }  
  
//     public static void main(String args[])
//     {  
//         Showable.Message obj=new Main();//upcasting here  
//         obj.msg();  
//     }  
// }



// //2. Interface nested in a class

// class A{  
//   interface Message{  
//   void msg();  
//   }  
// }  
  
// class Main implements A.Message{  
//  public void msg(){System.out.println("Hello nested interface");}  
  
//  public static void main(String args[]){  
//   A.Message obj = new Main(); //upcasting here  
//   obj.msg();  
//  }  
// }

