import java.util.*;

public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter the no. of rows: ");
		int r = sc.nextInt();
		System.out.println("\nEnter the no. of cols: ");
		int c = sc.nextInt();
		int[][] arr = new int[r][c];
		for(int i=0;i<r;i++)
		{
		    for(int j=0;j<c;j++)
		    {
		        System.out.println("\nEnter the number at " + i + j + ": ");
		        arr[i][j]=sc.nextInt();
		    }
		}
		
		System.out.println("\nDisplaying marix: ");
		for(int i=0;i<r;i++)
		{
		    for(int j=0;j<c;j++)
		    {
		        System.out.print(arr[i][j]+" ");
		        
		    }
		    System.out.println();
		}
		
	}
}
