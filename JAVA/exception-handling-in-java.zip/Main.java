// public class Main {  
  
//     public static void main(String[] args) {  
//         try  
//         {  
//         int arr[]= {1,3,5,7};  
//         System.out.println(arr[10]); //may throw exception   
//         throw new Exception("Exception occurred !!");
//         }  
//             // handling the array exception  
//         catch(Exception e)  
//         {  
//             System.out.println(e);  
//         }  
//         System.out.println("rest of the code");  
//     }  
      
// } 


// throw keyword

// public class Main {
//   static void checkAge(int age) {
//     if (age < 18) {
//       throw new ArithmeticException("Access denied - You must be at least 18 years old.");
//     }
//     else {
//       System.out.println("Access granted - You are old enough!");
//     }
//   }

//   public static void main(String[] args) {
//     checkAge(10); // Set age to 15 (which is below 18...)
//   }
// }




// Java program to demonstrate working of throws
// public class Main
// {
// 	static void fun() throws ArrayIndexOutOfBoundsException,IllegalAccessException
// 	{
// 		System.out.println("Inside fun(). ");
// 		throw new ArrayIndexOutOfBoundsException("demo");
// 	}
// 	public static void main(String args[])
// 	{
// 		try
// 		{
// 			fun();
// 		}
// 		catch(Exception e)
// 		{
// 			System.out.println("caught in main.");
// 		}
// 	}
// }





// finally block
  
// public class Main {
//     public static void main(String[] args)
//     {
//         try {
//             System.out.println("inside try block");
            
//             // Not throw any exception
//             System.out.println(34 / 2);
//         }
        
//         // Not execute in this case
//         catch (Exception e) {
            
//             System.out.println("Arithmetic Exception");
            
//         }
//         // Always execute
//         finally {
            
//             System.out.println(
//                 "finally : i execute always.");
            
//         }
//     }
// }


// public class Main {
//     public static void main(String[] args)
//     {
//         try {
//             System.out.println("Inside try block");
  
//             // Throw an Arithmetic exception
//             System.out.println(34 / 0);
//         }
  
//         // Can not accept Arithmetic type exception
//         // Only accept Null Pointer type Exception
//         catch (NullPointerException e) {
  
//             System.out.println(
//                 "catch : exception not handled.");
//         }
  
//         // Always execute
//         finally {
  
//             System.out.println(
//                 "finally : i will execute always.");
//         }
//         // This will not execute
//         System.out.println("i want to run");
//     }
// }





// Multiple catch

// public class Main {  
  
//     public static void main(String[] args) {  
          
//           try{    
//                 int a[]=new int[5];    
//                 a[5]=30/0;    
//               }    
//               catch(ArithmeticException e)  
//                   {  
//                   System.out.println("Arithmetic Exception occurs");  
//                   }    
//               catch(ArrayIndexOutOfBoundsException e)  
//                   {  
//                   System.out.println("ArrayIndexOutOfBounds Exception occurs");  
//                   }    
//               catch(Exception e)  
//                   {  
//                   System.out.println("Parent Exception occurs");  
//                   }             
//               System.out.println("rest of the code");    
//     }  
// }  





//Nested try

// class Main {

// 	// main method
// 	public static void main(String args[])
// 	{
// 		// Main try block
// 		try {

// 			// initializing array
// 			int a[] = { 1, 2, 3, 4, 5 };

// 			// trying to print element at index 5
// 			System.out.println(a[5]);

// 			// try-block2 inside another try block
// 			try {

// 				// performing division by zero
// 				int x = a[2] / 0;
// 			}
// 			catch (ArithmeticException e2) {
// 				System.out.println("division by zero is not possible");
// 			}
// 		}
// 		catch (ArrayIndexOutOfBoundsException e1) {
// 			System.out.println("ArrayIndexOutOfBoundsException");
		
// 		}
// 	}
	
// }



class MyCustomException extends Exception  
{  
    
}  
    
// class that uses custom exception MyCustomException  
public class Main  
{  
    // main method  
    public static void main(String args[])  
    {  
        try  
        {  
            // throw an object of user defined exception  
            throw new MyCustomException();  
        }  
        catch (MyCustomException ex)  
        {  
            System.out.println("Caught the exception");  
            System.out.println(ex.getMessage());  
        }  
  
        System.out.println("rest of the code...");    
    }  
}  
